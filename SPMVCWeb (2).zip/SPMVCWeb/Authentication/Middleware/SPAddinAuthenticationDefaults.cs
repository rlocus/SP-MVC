﻿namespace AspNet.Owin.SharePoint.Addin.Authentication.Middleware
{
	public class SPAddinAuthenticationDefaults
	{
		public const string AuthenticationType = "SPAddin";
	}
}
