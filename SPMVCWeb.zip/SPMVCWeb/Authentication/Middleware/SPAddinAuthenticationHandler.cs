﻿using System;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using AspNet.Owin.SharePoint.Addin.Authentication.Common;
using AspNet.Owin.SharePoint.Addin.Authentication.Provider;
using Microsoft.Owin.Logging;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Infrastructure;
using AspNet.Owin.SharePoint.Addin.Authentication.Context;
using System.Web;

namespace AspNet.Owin.SharePoint.Addin.Authentication.Middleware
{
    public class SPAddInAuthenticationHandler : AuthenticationHandler<SPAddInAuthenticationOptions>
    {
        private readonly ILogger _logger;

        public SPAddInAuthenticationHandler(ILogger logger)
        {
            _logger = logger;
        }

        protected override async Task<AuthenticationTicket> AuthenticateCoreAsync()
        {
            Uri redirectUrl;
            //if (string.IsNullOrEmpty(Options.ClientId)) return AuthenticateResult.Fail("ClientId is not configured in the appsettings.json file.");

            //Set the default error message when no SP Auth is attempted
            //AuthenticateResult result = AuthenticateResult.Fail("Could not handle SharePoint authentication.");

            var authenticationProperties = Options.StateDataFormat.Unprotect(Request.Query["state"]) ??
                                           new AuthenticationProperties();
            authenticationProperties.ExpiresUtc = DateTimeOffset.UtcNow.AddDays(10);
            authenticationProperties.IsPersistent = false;
            authenticationProperties.AllowRefresh = false;


            // Sets up the SharePoint configuration based on the middleware options.
            //var spContextProvider = SharePointContextProvider.GetInstance(
            //    SharePointConfiguration.GetFromSharePointAuthenticationOptions(Options));

            var httpContext = ((System.Web.HttpContextBase)Context.Environment["System.Web.HttpContextBase"]);
            ClaimsIdentity identity;
            AuthenticationTicket ticket = null;
            switch (SharePointContextProvider.CheckRedirectionStatus(httpContext, out redirectUrl))
            {
                case RedirectionStatus.Ok:
                    // Gets the current SharePoint context
                    var spContext = SharePointContextProvider.Current.GetSharePointContext(httpContext);
                    // Gets the SharePoint context CacheKey. The CacheKey would be assigned as issuer for new claim.
                    // It is also used to validate identity that is authenticated.
                    //Currently, we don't support High Trust
                    var userCacheKey = ((SharePointAcsContext)spContext).CacheKey;
                    if (Context.Authentication.User.Identity.IsAuthenticated &&
                        Context.Authentication.User.Identity.AuthenticationType == SPAddinAuthenticationDefaults.AuthenticationType)
                    {
                        identity = (ClaimsIdentity)Context.Authentication.User.Identity;
                    }
                    else
                    {
                        //build a claims identity and principal
                        identity = new ClaimsIdentity(SPAddinAuthenticationDefaults.AuthenticationType);
                        // Adds claims with the SharePoint context CacheKey as issuer to the Identity object.
                        var claims = new[]
                        {
                            new Claim(ClaimTypes.Authentication, userCacheKey, "SPCacheKey",  GetType().Assembly.GetName().Name),
                        };

                        identity.AddClaims(claims);
                        var principal = new ClaimsPrincipal(identity);

                        // Handles the sign in method of the SP auth middleware
                        //Context.Authentication.SignIn(authenticationProperties, identity);

                        //sign in the cookie middleware so it issues a cookie
                        //if (!string.IsNullOrWhiteSpace(this.Options.CookieAuthenticationScheme))
                        //{
                        //    SignInAccepted = true;
                        //    Context.Authentication.SignIn(authenticationProperties, identity);
                        //}
                    }

                    // Creates the authentication ticket.
                    ticket = new AuthenticationTicket(identity, authenticationProperties);
                    //result = AuthenticateResult.Success(ticket);

                    //Throw auth ticket success event
                    await Options.Provider.AuthenticationSucceeded(
                        new AuthenticationSucceededContext(Context, Options)
                        {
                            SharePointContext = spContext
                        });

                    //Log success
                    //LoggingExtensions.TokenValidationSucceeded(this.Logger);

                    break;
                case RedirectionStatus.ShouldRedirect:
                    Context.Response.StatusCode = 301;
                    //result = AuthenticateResult.Fail("ShouldRedirect");

                    // Signs out so new signin to be performed on redirect back from SharePoint
                    identity = (ClaimsIdentity)Context.Authentication.User.Identity;
                    //Context.Authentication.SignIn(authenticationProperties, identity);
                    authenticationProperties.RedirectUri = redirectUrl.AbsoluteUri;
                    ticket = new AuthenticationTicket(identity, authenticationProperties);
                    // Redirect to get new context token
                    //Context.Response.Redirect(redirectUrl.AbsoluteUri);
                    break;
                case RedirectionStatus.CanNotRedirect:
                    //result = AuthenticateResult.Fail("No SPHostUrl to build a SharePoint Context, but Authenticate was called on the SharePoint middleware.");

                    //Log that we cannot redirect
                    //LoggingExtensions.CannotRedirect(this.Logger);

                    //Throw failed event
                    await Options.Provider.AuthenticationFailed(new AuthenticationFailedContext(Context, Options));
                    identity = (ClaimsIdentity)Context.Authentication.User.Identity;
                    ticket = new AuthenticationTicket(identity, authenticationProperties);
                    break;
            }

            return ticket;
        }

        //   protected override async Task<AuthenticationTicket> AuthenticateCoreAsync()
        //{
        //	ClaimsIdentity identity;

        //	if (Context.Authentication.User.Identity.IsAuthenticated && 
        //		Context.Authentication.User.Identity.AuthenticationType == Options.SignInAsAuthenticationType)
        //	{
        //		identity = (ClaimsIdentity) Context.Authentication.User.Identity;
        //	}
        //	else
        //	{
        //		identity = new ClaimsIdentity(Options.SignInAsAuthenticationType);
        //	}

        //	Uri spHostUrl;
        //	if (!Uri.TryCreate(Request.Query[SharePointContext.SPHostUrlKey], UriKind.Absolute, out spHostUrl))
        //	{
        //		throw new Exception("Can not get host url from query string");
        //	}

        //	Uri spAppWebUrl;
        //	if (Uri.TryCreate(Request.Query[SharePointContext.SPAppWebUrlKey], UriKind.Absolute, out spAppWebUrl))
        //	{
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.SPAppWebUrl, spAppWebUrl.AbsoluteUri));
        //	}

        //	string accessToken;

        //	if (AuthHelper.IsHighTrustApp())
        //	{
        //		var userSid = AuthHelper.GetWindowsUserSid(Context);
        //		accessToken = AuthHelper.GetS2SAccessToken(spHostUrl, userSid);

        //		identity.AddClaim(new Claim(SPAddinClaimTypes.ADUserId, userSid));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.CacheKey, userSid));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.Realm, AuthHelper.GetRealmFromTargetUrl(spHostUrl)));
        //	}
        //	else
        //	{
        //		var contextTokenString = AuthHelper.GetContextTokenFromRequest(Request);
        //		var contextToken = AuthHelper.ReadAndValidateContextToken(contextTokenString, Request.Uri.Authority);

        //		identity.AddClaim(new Claim(SPAddinClaimTypes.RefreshToken, contextToken.RefreshToken));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.Realm, contextToken.Realm));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.TargetPrincipalName, contextToken.TargetPrincipalName));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.CacheKey, contextToken.CacheKey));

        //		accessToken = AuthHelper.GetAcsAccessToken(contextToken.RefreshToken, contextToken.TargetPrincipalName, spHostUrl.Authority, contextToken.Realm);
        //	}

        //	return await CreateTicket(accessToken, identity, spHostUrl);
        //}

        protected override Task ApplyResponseChallengeAsync()
        {
            if (Response.StatusCode == 401)
            {
                var challenge = Helper.LookupChallenge(Options.AuthenticationType, Options.AuthenticationMode);

                if (challenge == null)
                {
                    return Task.FromResult<object>(null);
                }

                var state = challenge.Properties;

                var hostUrl = new Uri(state.Dictionary[SharePointContext.SPHostUrlKey]);

                var uriBuilder = new UriBuilder(Request.Uri)
                {
                    Path = Options.CallbackPath.Value
                };
                state.Dictionary.Remove(SharePointContext.SPHostUrlKey);
                GenerateCorrelationId(state);
                var stateString = Options.StateDataFormat.Protect(state);
                var postRedirectUrl = uriBuilder.Uri.GetLeftPart(UriPartial.Path) + "?{StandardTokens}&SPAppWebUrl={SPAppWebUrl}&state=" + stateString;
                var redirectUri = TokenHelper.GetAppContextTokenRequestUrl(hostUrl.AbsoluteUri, WebUtility.UrlEncode(postRedirectUrl));
                _logger.WriteInformation("Redirecting to SharePoint AppRedirect");
                Response.Redirect(redirectUri);
            }

            return Task.FromResult<object>(null);
        }


        public override async Task<bool> InvokeAsync()
        {
            //if (Options.CallbackPath.HasValue && Options.CallbackPath == Request.Path)
            //{
                var ticket = await AuthenticateAsync();
                if (ticket != null)
                {
                    if (ticket.Identity != null)
                    {
                        Context.Authentication.SignIn(ticket.Properties, ticket.Identity);
                    }
                    var hasAppReturnUrl = false;
                    var redirectUrl = string.Empty;

                    if (Options.AuthenticationMode == AuthenticationMode.Passive)
                    {
                        if (ticket.Properties.RedirectUri != null && ticket.Properties.RedirectUri.ToLower().Contains("redirecturl"))
                        {
                            var index = ticket.Properties.RedirectUri.IndexOf("=");
                            if (index != -1)
                            {
                                hasAppReturnUrl = true;
                                redirectUrl = ticket.Properties.RedirectUri.Substring(index + 1);
                                redirectUrl = HttpUtility.UrlDecode(redirectUrl).Replace("//", "/");
                            }
                        }
                    }

                    if (hasAppReturnUrl)
                    {
                        if (!string.IsNullOrEmpty(redirectUrl))
                        {
                            Response.Redirect(redirectUrl);
                        }
                    }
                    else
                    {
                        if (ticket.Properties.RedirectUri != null)
                        {
                            Response.Redirect(ticket.Properties.RedirectUri);
                        }
                    }

                    // Prevent further processing by the owin pipeline.
                    return true;
                }
            //}

            // Let the rest of the pipeline run.
            return false;
        }

        //public override async Task<bool> InvokeAsync()
        //{
        //    //if (Options.CallbackPath.HasValue && Options.CallbackPath == Request.Path)
        //    //{
        //        _logger.WriteInformation("Receiving contextual information");

        //        if (AuthHelper.IsHighTrustApp())
        //        {
        //            var logonUserIdentity = AuthHelper.GetHttpRequestIdentity(Context);

        //            // If not authenticated and we are using integrated windows auth, then force user to login
        //            if (!logonUserIdentity.IsAuthenticated && logonUserIdentity is WindowsIdentity)
        //            {
        //                Response.StatusCode = 418;
        //                // Prevent further processing by the owin pipeline.
        //                return true;
        //            }
        //        }

        //        var state = Request.Query["state"];
        //        var properties = Options.StateDataFormat.Unprotect(state);
        //        if (properties != null && !ValidateCorrelationId(properties, _logger))
        //        {
        //            throw new Exception("Correlation failed.");
        //        }

        //        var ticket = await AuthenticateAsync();
        //        if (ticket != null)
        //        {
        //            //ticket.Identity.AddClaim(new Claim(SPAddinClaimTypes.SPAddinAuthentication, "1"));
        //            //Context.Authentication.SignIn(ticket.Properties, ticket.Identity);
        //            //Response.Redirect(ticket.Properties.RedirectUri);
        //            // Prevent further processing by the owin pipeline.
        //            return true;
        //        }
        //    //}

        //    //	// Let the rest of the pipeline run.
        //    return false;
        //}

        //private async Task<AuthenticationTicket> CreateTicket(string accessToken, ClaimsIdentity identity, Uri spHostUrl)
        //{
        //	using (var clientContext = AuthHelper.GetClientContextWithAccessToken(spHostUrl.AbsoluteUri, accessToken))
        //	{
        //		var user = clientContext.Web.CurrentUser;
        //		clientContext.Load(user);
        //		clientContext.ExecuteQuery();

        //		identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.LoginName, null, Options.AuthenticationType));
        //		identity.AddClaim(new Claim(ClaimTypes.Name, user.Title));
        //		identity.AddClaim(new Claim(ClaimTypes.Email, user.Email));
        //		identity.AddClaim(new Claim(SPAddinClaimTypes.SPHostUrl, spHostUrl.AbsoluteUri));

        //		var properties = Options.StateDataFormat.Unprotect(Request.Query["state"]);

        //		//await Options.Provider.Authenticated(new SPAddinAuthenticatedContext(Context, user, identity));

        //		return new AuthenticationTicket(identity, properties);
        //	}
        //}
    }
}
