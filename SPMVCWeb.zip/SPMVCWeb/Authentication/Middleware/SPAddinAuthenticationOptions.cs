﻿using AspNet.Owin.SharePoint.Addin.Authentication.Provider;
using Microsoft.Owin;
using Microsoft.Owin.Security;

namespace AspNet.Owin.SharePoint.Addin.Authentication.Middleware
{
	public class SPAddInAuthenticationOptions : AuthenticationOptions
	{
        /// <summary>
        /// Gets or sets if HTTPS is required for the metadata address or authority.
        /// The default is true. This should be disabled only in development environments.
        /// </summary>
        public bool RequireHttpsMetadata { get; set; } = true;

        /// <summary>
        /// Gets or sets ClientId.
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets ClientSecret.
        /// </summary>
        public string ClientSecret { get; set; }

        /// <summary>
        /// Gets or sets IssuerId.
        /// </summary>
        public string IssuerId { get; set; }

        /// <summary>
        /// Gets or sets HostedAppHostNameOverride.
        /// </summary>
        public string HostedAppHostNameOverride { get; set; }

        /// <summary>
        /// Gets or sets HostedAppHostName.
        /// </summary>
        public string HostedAppHostName { get; set; }

        /// <summary>
        /// Gets or sets SecondaryClientSecret.
        /// </summary>
        public string SecondaryClientSecret { get; set; }

        /// <summary>
        /// Gets or sets Realm.
        /// </summary>
        public string Realm { get; set; }

        /// <summary>
        /// Gets or sets ClientSigningCertificatePath.
        /// </summary>
        public string ClientSigningCertificatePath { get; set; }

        /// <summary>
        /// Gets or sets ClientSigningCertificatePassword.
        /// </summary>
        public string ClientSigningCertificatePassword { get; set; }

        /// <summary>
        /// If set, the SP Authentication middleware will also call the SignIn method for the provided 
        /// Cookie authentication scheme
        /// </summary>
        //public string CookieAuthenticationScheme { get; set; }

        public ISPAddinAuthenticationProvider Provider { get; set; }

        public ISecureDataFormat<AuthenticationProperties> StateDataFormat { get; set; }

        public PathString CallbackPath { get; set; }

        public SPAddInAuthenticationOptions() : base(SPAddinAuthenticationDefaults.AuthenticationType)
		{
			Description.Caption = SPAddinAuthenticationDefaults.AuthenticationType;
            AuthenticationMode = AuthenticationMode.Passive;
        }
	}
}
