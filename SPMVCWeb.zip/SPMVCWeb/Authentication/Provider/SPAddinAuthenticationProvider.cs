﻿using AspNet.Owin.SharePoint.Addin.Authentication.Context;
using System;
using System.Threading.Tasks;

namespace AspNet.Owin.SharePoint.Addin.Authentication.Provider
{
	public class SPAddinAuthenticationProvider : ISPAddinAuthenticationProvider
	{
		//public Func<SPAddinAuthenticatedContext, Task> OnAuthenticated { get; set; }

		//public SPAddinAuthenticationProvider()
		//{
		//	OnAuthenticated = context => Task.FromResult<object>(null);
		//}

		//public Task Authenticated(SPAddinAuthenticatedContext context)
		//{
		//	return OnAuthenticated(context);
		//}

        /// <summary> 
        /// Invoked when the SharePoint authentication process has succeeded and authenticated the user. 
        /// </summary> 
        public Func<AuthenticationFailedContext, Task> OnAuthenticationFailed { get; set; } = context => Task.FromResult(0);

        /// <summary> 
        /// Invoked when the authentication handshaking failed and the user is not authenticated.
        /// </summary> 
        public Func<AuthenticationSucceededContext, Task> OnAuthenticationSucceeded { get; set; } = context => Task.FromResult(0);

        public virtual Task AuthenticationFailed(AuthenticationFailedContext context) => OnAuthenticationFailed(context);

        public virtual Task AuthenticationSucceeded(AuthenticationSucceededContext context) => OnAuthenticationSucceeded(context);
    }
}
