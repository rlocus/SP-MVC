﻿using AspNet.Owin.SharePoint.Addin.Authentication.Context;
using System.Threading.Tasks;

namespace AspNet.Owin.SharePoint.Addin.Authentication.Provider
{
	public interface ISPAddinAuthenticationProvider
	{
        /// <summary>  
        /// Invoked when the Active Directory authentication process has succeeded and authenticated the user.  
        /// </summary>  
        Task AuthenticationSucceeded(AuthenticationSucceededContext context);

        /// <summary>  
        /// Invoked when the authentication handshaking failed and the user is not authenticated. 
        /// </summary>  
        Task AuthenticationFailed(AuthenticationFailedContext context);
    }
}
